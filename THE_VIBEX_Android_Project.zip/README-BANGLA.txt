THE VIBEX Android Project — Version 1.0

এই ZIP-এ Android Studio project source আছে। এটি APK নয়।
APK build করতে GitHub Actions ব্যবহার করা যাবে, অথবা Android Studio-তে project খুলে build করা যাবে।

ফোন দিয়ে GitHub পদ্ধতি:
1. github.com-এ account খুলে sign in করো।
2. New repository তৈরি করো; নাম দাও the-vibex (Public বা Private)।
3. এই ZIP extract করে এর ভেতরের সব ফাইল repository-তে upload করো। ZIP ফাইলটিকে একা upload করলে হবে না; folder-এর ভেতরের files/folders upload করতে হবে।
4. Upload শেষে repository-র Actions tab খোলো।
5. "Build THE VIBEX APK" workflow নির্বাচন করে Run workflow চাপো।
6. Build শেষ হলে workflow run খুলে নিচে Artifacts থেকে THE-VIBEX-debug-apk download করো।
7. ZIP artifact extract করলে app-debug.apk পাবে। Android-এ install করার আগে Android-এর অনুমতি চাইতে পারে।

যদি Actions tab না দেখায়:
- Settings > Actions > General-এ গিয়ে Actions অনুমোদিত আছে কি না দেখো।
- Repository default branch main কিনা নিশ্চিত করো।
- .github/workflows/build-apk.yml সঠিক path-এ আছে কিনা দেখো।

গুরুত্বপূর্ণ:
- এই APK একটি offline UI prototype; এতে আসল movie/anime/song catalogue, streaming server, login backend বা বাস্তব media downloads নেই।
- Media playback ও download পরে যোগ করতে হবে, কেবল নিজের/লাইসেন্সপ্রাপ্ত/অনুমতিপ্রাপ্ত content দিয়ে।
- Debug APK testing-এর জন্য। Public release-এর জন্য আলাদা signed release build প্রয়োজন।
